document.addEventListener('DOMContentLoaded', () => {
    // Fetch data from the API
    fetch('/api/tour_data')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            populateHotels(data.hotels);
            populateAttractions(data.attractions);
        })
        .catch(error => {
            console.error('Error fetching tour data:', error);
        });

    // Function to populate hotels section
    function populateHotels(hotels) {
        const hotelsDiv = document.getElementById('hotels');
        hotelsDiv.innerHTML = '';  // Clear any existing content

        hotels.forEach(hotel => {
            const hotelElement = document.createElement('div');
            hotelElement.className = 'hotel';
            hotelElement.innerHTML = `
                <h3>${hotel.name}</h3>
                <p>${hotel.description}</p>
                <img src="${hotel.image_url}" alt="${hotel.name}">
            `;
            hotelsDiv.appendChild(hotelElement);
        });
    }

    // Function to populate attractions section
    function populateAttractions(attractions) {
        const attractionsDiv = document.getElementById('attractions');
        attractionsDiv.innerHTML = '';  // Clear any existing content

        attractions.forEach(attraction => {
            const attractionElement = document.createElement('div');
            attractionElement.className = 'attraction';
            attractionElement.innerHTML = `
                <h3>${attraction.name}</h3>
                <p>${attraction.description}</p>
                <img src="${attraction.image_url}" alt="${attraction.name}">
            `;
            attractionsDiv.appendChild(attractionElement);
        });
    }

    // Handle contact form submission
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);

            fetch('/api/contact', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(message => {
                alert(message);
                contactForm.reset();
            })
            .catch(error => {
                console.error('Error submitting contact form:', error);
            });
        });
    }
});
